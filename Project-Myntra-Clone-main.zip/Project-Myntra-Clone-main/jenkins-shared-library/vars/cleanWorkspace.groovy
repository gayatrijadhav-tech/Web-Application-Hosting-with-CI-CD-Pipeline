
def call() {
    cleanWs()
}

